# Student Records

This folder is reserved for exported student-record documents.

The MySQL database is the permanent source of student data.
When the user clicks **Document**, Node.js generates an HTML student-record document here and also sends it to the browser.

Generated files follow this pattern:

`student-<id>.html`
