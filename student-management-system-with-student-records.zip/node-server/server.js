const express = require("express");
const path = require("path");
const { spawn } = require("child_process");

const app = express();
const PORT = process.env.PORT || 3000;
const JAVA_JAR = path.join(__dirname, "..", "java-backend", "target", "student-management-java-1.0.0.jar");
const RECORDS_DIR = path.join(__dirname, "..", "student_records");


app.use(express.json());
app.use(express.static(path.join(__dirname, "..", "frontend")));

let javaProcess;
let requestId = 0;
const pending = new Map();

function startJavaBackend() {
  javaProcess = spawn("java", ["-jar", JAVA_JAR], {
    cwd: path.join(__dirname, ".."),
    env: process.env
  });

  let buffer = "";
  javaProcess.stdout.on("data", data => {
    buffer += data.toString();
    const lines = buffer.split("\n");
    buffer = lines.pop();

    for (const line of lines) {
      if (!line.trim()) continue;
      try {
        const msg = JSON.parse(line);
        const waiter = pending.get(msg.requestId);
        if (waiter) {
          pending.delete(msg.requestId);
          waiter(msg);
        }
      } catch (e) {
        console.error("Invalid Java response:", line);
      }
    }
  });

  javaProcess.stderr.on("data", data => {
    console.error("[Java]", data.toString().trim());
  });

  javaProcess.on("exit", code => {
    console.error(`Java backend exited with code ${code}`);
  });
}

function javaRequest(action, data = {}) {
  return new Promise((resolve, reject) => {
    if (!javaProcess || javaProcess.killed) {
      return reject(new Error("Java backend is not running"));
    }
    const id = ++requestId;
    pending.set(id, msg => {
      if (msg.ok) resolve(msg);
      else reject(new Error(msg.error || "Java backend error"));
    });
    javaProcess.stdin.write(JSON.stringify({ requestId: id, action, ...data }) + "\n");
  });
}

app.get("/api/students", async (req, res) => {
  try {
    const result = await javaRequest("list");
    res.json(result.students);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post("/api/students", async (req, res) => {
  try {
    const { name, email, age, course, phone } = req.body;
    if (!name || !email || !course || !age) {
      return res.status(400).json({ error: "Name, email, age and course are required." });
    }
    const result = await javaRequest("add", { student: { name, email, age: Number(age), course, phone: phone || "" } });
    res.status(201).json(result.student);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.delete("/api/students/:id", async (req, res) => {
  try {
    await javaRequest("delete", { id: Number(req.params.id) });
    res.json({ message: "Student deleted successfully." });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.get("/api/students/:id/document", async (req, res) => {
  try {
    const result = await javaRequest("get", { id: Number(req.params.id) });
    const s = result.student;

    const escapeHtml = value => String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;");

    const html = `<!doctype html>
<html><head><meta charset="UTF-8"><title>Student Record - ${escapeHtml(s.name)}</title>
<style>
body{font-family:Arial,sans-serif;margin:40px;color:#222}
.document{max-width:800px;margin:auto;border:1px solid #ddd;padding:30px;border-radius:12px}
h1{text-align:center}.row{padding:10px;border-bottom:1px solid #eee}
.label{font-weight:bold;display:inline-block;width:150px}
</style></head><body><div class="document">
<h1>Student Record</h1>
<div class="row"><span class="label">Student ID</span>${escapeHtml(s.id)}</div>
<div class="row"><span class="label">Name</span>${escapeHtml(s.name)}</div>
<div class="row"><span class="label">Email</span>${escapeHtml(s.email)}</div>
<div class="row"><span class="label">Age</span>${escapeHtml(s.age)}</div>
<div class="row"><span class="label">Course</span>${escapeHtml(s.course)}</div>
<div class="row"><span class="label">Phone</span>${escapeHtml(s.phone)}</div>
<div class="row"><span class="label">Created At</span>${escapeHtml(s.createdAt)}</div>
</div></body></html>`;

    // Save a copy in the Student Records folder.
    require("fs").mkdirSync(RECORDS_DIR, { recursive: true });
    require("fs").writeFileSync(
      path.join(RECORDS_DIR, `student-${s.id}.html`),
      html,
      "utf8"
    );

    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="student-${s.id}.html"`);
    res.send(html);
  } catch (e) {
    res.status(404).json({ error: e.message });
  }
});

app.get("/api/students/document/all", async (req, res) => {
  try {
    const result = await javaRequest("list");
    const students = result.students;
    const escapeHtml = value => String(value ?? "")
      .replaceAll("&", "&amp;").replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;").replaceAll('"', "&quot;");

    const rows = students.map(s => `
      <tr>
        <td>${escapeHtml(s.id)}</td><td>${escapeHtml(s.name)}</td>
        <td>${escapeHtml(s.email)}</td><td>${escapeHtml(s.age)}</td>
        <td>${escapeHtml(s.course)}</td><td>${escapeHtml(s.phone)}</td>
        <td>${escapeHtml(s.createdAt)}</td>
      </tr>`).join("");

    const html = `<!doctype html><html><head><meta charset="UTF-8">
<title>Student Records</title>
<style>
body{font-family:Arial,sans-serif;margin:30px}.wrap{max-width:1200px;margin:auto}
h1{text-align:center}table{width:100%;border-collapse:collapse}
th,td{border:1px solid #ddd;padding:9px;text-align:left}th{background:#f3f4f6}
</style></head><body><div class="wrap">
<h1>Student Records</h1>
<table><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Age</th>
<th>Course</th><th>Phone</th><th>Created At</th></tr></thead>
<tbody>${rows}</tbody></table></div></body></html>`;

    require("fs").mkdirSync(RECORDS_DIR, { recursive: true });
    require("fs").writeFileSync(path.join(RECORDS_DIR, "all-student-records.html"), html, "utf8");

    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.setHeader("Content-Disposition", 'attachment; filename="all-student-records.html"');
    res.send(html);
  } catch (e) {
    res.status(500).json({error:e.message});
  }
});

app.get("/api/health", (req, res) => res.json({ node: "OK", java: !!javaProcess && !javaProcess.killed }));

startJavaBackend();

app.listen(PORT, () => {
  console.log(`Student Management System: http://localhost:${PORT}`);
});
