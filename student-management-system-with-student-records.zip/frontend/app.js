const form = document.getElementById("studentForm");
const table = document.getElementById("studentTable");
const message = document.getElementById("message");
const search = document.getElementById("search");
let students = [];

async function loadStudents() {
  const res = await fetch("/api/students");
  students = await res.json();
  render();
}

function render() {
  const q = search.value.toLowerCase().trim();
  const filtered = students.filter(s =>
    s.name.toLowerCase().includes(q) || s.course.toLowerCase().includes(q)
  );

  table.innerHTML = filtered.map(s => `
    <tr>
      <td>${s.id}</td><td>${escapeHtml(s.name)}</td><td>${escapeHtml(s.email)}</td>
      <td>${s.age}</td><td>${escapeHtml(s.course)}</td><td>${escapeHtml(s.phone)}</td>
      <td>
        <button class="action doc" onclick="downloadDocument(${s.id})">Document</button>
        <button class="action delete" onclick="deleteStudent(${s.id})">Delete</button>
      </td>
    </tr>`).join("");
}

function escapeHtml(v) {
  return String(v ?? "").replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[c]));
}

form.addEventListener("submit", async e => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(form));
  const res = await fetch("/api/students", {
    method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(data)
  });
  const result = await res.json();
  if (!res.ok) {
    message.textContent = result.error || "Unable to save.";
    return;
  }
  message.textContent = "Student saved successfully.";
  form.reset();
  await loadStudents();
});

async function deleteStudent(id) {
  if (!confirm("Delete this student?")) return;
  const res = await fetch(`/api/students/${id}`, {method:"DELETE"});
  const result = await res.json();
  message.textContent = result.message || result.error;
  await loadStudents();
}

function downloadDocument(id) {
  window.location.href = `/api/students/${id}/document`;
}

search.addEventListener("input", render);
loadStudents().catch(err => message.textContent = "Server error: " + err.message);

function downloadAllRecords() { window.location.href = "/api/students/document/all"; }
