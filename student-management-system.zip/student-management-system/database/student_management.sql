CREATE DATABASE IF NOT EXISTS student_management;
USE student_management;
CREATE TABLE IF NOT EXISTS students (
 id INT PRIMARY KEY AUTO_INCREMENT,
 name VARCHAR(100) NOT NULL,
 email VARCHAR(150) NOT NULL UNIQUE,
 course VARCHAR(100) NOT NULL,
 year INT NOT NULL,
 phone VARCHAR(20),
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO students(name,email,course,year,phone) VALUES
('Dineel Anam','dineel@example.com','B.Tech CSE',3,'9876543210')
ON DUPLICATE KEY UPDATE name=VALUES(name);
