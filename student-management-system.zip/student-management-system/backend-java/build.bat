@echo off
if not exist out mkdir out
dir /s /b src\main\java\*.java > sources.txt
javac -cp "lib\mysql-connector-j.jar" -d out @sources.txt
java -cp "out;lib\mysql-connector-j.jar" com.studentmanagement.Main
